export const API_URL = 'https://forkify-api.herokuapp.com/api/v2/recipes/';
export const TIMEOUT_SECONDS = 10;
export const MESSAGE_DISPLAY_LENGTH_MILISECONDS = 3000;
export const RESULTS_PER_PAGE = 11;
export const MY_KEY = '56b8850d-16d0-490b-91ec-a239ebaf15d3'
export const SPOONAKULAR_KEY = '7e3058d25e674f1789eae22338e70b9e'